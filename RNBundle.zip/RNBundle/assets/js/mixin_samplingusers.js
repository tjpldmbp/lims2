// <!-- POP测量人模块 -->
Vue.component('pop_samplingusers', {
    props: ['showDialog', 'formData', 'formControl'],
    methods: {
        p_confirmDialogPerson_click: function () {
            this.$emit('confirm_dialog_person_click')
        },

        p_confirmSamplePerson_click: function () {
            this.$emit('confirm_sample_person_click')
        },
        p_confirmSampleDate_click: function (value) {
            this.$emit('confirm_sample_date_click', value)
        },
        // samplePersonclickselect: function (value) {
        //     this.$emit('samplePersonclickselect',value)
        // }
      
        samplePersonclickselect(item, index) {
            var ischecked = false;
            for (var i = 0; i < this.formControl.samplePersonSelected.length; i++) {
                //判断选中数组是否存在点击对象
                if (this.formControl.samplePersonSelected[i].user_ID == item.user_ID) {
                    ischecked = true;
                }
            }
            if (ischecked) {
                this.formControl.samplePersonSelected.remove(item);
            } else {
                //加上是单选 去掉是多选
                // this.formControl.samplePersonSelected = [];
                //插入
                this.formControl.samplePersonSelected.push(item);

            }
        },



    },
    template: `
    <van-popup v-model="showDialog.persons" position="bottom" :close-on-click-overlay="false">
    <van-nav-bar title="测量人" left-text="取消" right-text="确定" @click-left="showDialog.persons=false" @click-right="p_confirmDialogPerson_click"></van-nav-bar>
    <div class="popup-content">
        <van-cell-group>
            <van-cell title="测量人" :value="formData.personName" clickable="true" @click="showDialog.personspicker.samplePerson=true"></van-cell>
            <van-cell title="测量时间" :value="formData.personD.samplingDateLong == null ||formData.personD.samplingDateLong == 0? '': new Date(formData.personD.samplingDateLong).format('yyyy-MM-dd')"
                clickable="true" @click="showDialog.personspicker.sampleDate=true"></van-cell>
        </van-cell-group>
    </div>

    <van-popup v-model="showDialog.personspicker.samplePerson" :overlay="false" :close-on-click-overlay="false">
        <van-nav-bar title="测量人" left-text="取消" right-text="确定" @click-left="showDialog.personspicker.samplePerson=false"
            @click-right="p_confirmSamplePerson_click"></van-nav-bar>
        <van-checkbox-group v-model="formControl.samplePersonSelected">
            <van-cell-group>
                

                <van-cell v-for="(item, index) in formControl.samplePerson" :title="item.real_NAME" :key="item.user_ID" @click="samplePersonclickselect(item, index)"
                clickable>
                <van-checkbox :name="item" disabled></van-checkbox>
            </van-cell>

            </van-cell-group>
        </van-checkbox-group>
    </van-popup>

    <van-popup v-model="showDialog.personspicker.sampleDate" :overlay="false" :close-on-click-overlay="false">
        <van-datetime-picker v-model="formControl.sampleDate" title="采样日期" type="date" cancel-button-text="返回"
            @confirm="p_confirmSampleDate_click" @cancel="showDialog.personspicker.sampleDate=false"></van-datetime-picker>
    </van-popup>

</van-popup>
            `
})





// table
Vue.component('table_samplingusers', {
    props: ['result'],
    methods: {
        p_table_samplingusers_click: function () {
            this.$emit('table_samplingusers_click')
        }
    },
    template: `
        <table v-on:click="p_table_samplingusers_click" cellspacing="0" cellpadding="10" style="border-collapse:collapse; margin:0 auto; width:100%">
        <tr style="height:33.15pt">
                <td colspan="6" style="background-color:#ffffff; border-left-color:#ffffff; border-left-style:solid; border-left-width:0.75pt; border-right-color:#ffffff; border-right-style:solid; border-right-width:0.75pt; border-top-color:#000000; border-top-style:solid; border-top-width:0pt; padding-left:5.03pt; padding-right:5.03pt; vertical-align:middle; width:279.55pt">
                    <p style="margin:0pt; orphans:0; text-indent:31.5pt; widows:0">
                        <span style="font-family:宋体; font-size:12pt">测量人：</span>
                        <span style="font-family:宋体; font-size:12pt" v-for="todo in result.samplingUsers"  v-if="todo.name!=''">{{todo.name}},</span>
                    </p>
                    <p style="margin:0pt; orphans:0; text-indent:31.5pt; widows:0">
                        <span style="font-family:宋体; font-size:12pt">测量日期：{{
                            result.samplingDateLong
                        ==null || result.samplingDateLong==''||result.samplingDateLong==0? new Date().format('yyyy-MM-dd') : new Date(result.samplingDateLong).format('yyyy-MM-dd')
                        }}</span>
                    </p>
                </td>
                <td colspan="4" style="background-color:#ffffff; border-left-color:#ffffff; border-left-style:solid; border-left-width:0.75pt; border-right-color:#ffffff; border-right-style:solid; border-right-width:0.75pt; border-top-color:#000000; border-top-style:solid; border-top-width:0pt; padding-left:5.03pt; padding-right:5.03pt; vertical-align:middle; width:272.7pt">
                    <p style="margin:0pt; orphans:0; text-indent:31.5pt; widows:0">
                        <span style="font-family:宋体; font-size:12pt">复核人：</span>
                    </p>
                    <p style="margin:0pt; orphans:0; text-indent:31.5pt; widows:0">
                        <span style="font-family:宋体; font-size:12pt">复核日期：</span>
                    </p>
                </td>
                <td colspan="5" style="background-color:#ffffff; border-left-color:#ffffff; border-left-style:solid; border-left-width:0.75pt; border-right-color:#ffffff; border-right-style:solid; border-right-width:0.75pt; border-top-color:#000000; border-top-style:solid; border-top-width:0pt; padding-left:5.03pt; padding-right:5.03pt; vertical-align:middle; width:201.85pt">
                    <p style="margin:0pt; orphans:0; text-indent:26.25pt; widows:0">
                        <span style="font-family:宋体; font-size:12pt">审核人：</span>
                    </p>
                    <p style="margin:0pt; orphans:0; text-indent:26.25pt; widows:0">
                        <span style="font-family:宋体; font-size:12pt">审核日期：</span>
                    </p>
                </td>
        </tr>
        <tr style="height:15pt">
        </tr>
    </table>
    `
})



mixin_samplingusers = {

    data: {
        showDialog: {
            persons: false,
            personspicker: {
                samplePerson: false,
                sampleDate: false,
            }
        },
        formControl: {
            //测量人
            samplePerson: [],
            samplePersonSelected: [],

        },
        formData: {
            personName: "",
            personD: {},
        }
    },


    methods: {

        /////////////////////////////////////////测量人选择区域//////////////////////////////////////////////////////
        //提取联系人
        makePerson() {
            console.log("----make-->",this.result.samplingUsers);
          
            var personname = "";
            for (var i = 0; i < this.result.samplingUsers.length; i++) {
                personname = personname + this.result.samplingUsers[i].name;
                if (i < this.result.samplingUsers.length - 1) {
                    personname += ",";
                }
            }
            this.formData.personName = personname;
            var obj = {};
            obj.samplingDateLong = this.result.samplingDateLong == null || this.result.samplingDateLong == 0 ? new Date().getTime() : this.result.samplingDateLong;
            this.formData.personD = obj;

            this.formControl.sampleDate = new Date(this.formData.personD.samplingDateLong);

            this.formControl.samplePersonSelected = [];
            for (var i = 0; i < this.formControl.samplePerson.length; i++) {
                if (personname != null &&
                    personname != undefined &&
                    personname.indexOf(this.formControl.samplePerson[i].real_NAME) != -1) {
                    this.formControl.samplePersonSelected.push(this.formControl.samplePerson[i]);
                }
            }

            this.showDialog.persons = true;
        },


        confirmSamplePerson() {
            //先质控一下数组
            this.formData.personD.samplingUsers = [];
            var samplePersonNameStr = "";
            for (var i = 0; i < this.formControl.samplePersonSelected.length; i++) {
                samplePersonNameStr = samplePersonNameStr + this.formControl.samplePersonSelected[i].real_NAME;
                if (i < this.formControl.samplePersonSelected.length - 1) {
                    samplePersonNameStr += ",";
                }
                //往数组插入人员对象
                var obj = {};
                obj.id = i;
                obj.id = this.formControl.samplePersonSelected[i].user_ID,
                    // obj.username = this.formControl.samplePersonSelected[i].real_NAME,
                    // obj.realName = this.formControl.samplePersonSelected[i].real_NAME,
                    // obj.idCard = "",
                    obj.id = this.formControl.samplePersonSelected[i].user_ID,
                    obj.name = this.formControl.samplePersonSelected[i].real_NAME,
                    this.formData.personD.samplingUsers.push(obj);
            }
            this.formData.personName = samplePersonNameStr;
            this.showDialog.personspicker.samplePerson = false;
        },


        confirmSampleDate(value) {
            console.log("88", value)
            this.formData.personD.samplingDateLong = value.getTime();
            this.showDialog.personspicker.sampleDate = false;
        },
        confirmDialogPerson() {
           
/////////////////////////////////////////////////////////////////
            if( this.formControl.samplePersonSelected.length>0){
                //先质控一下数组
            this.formData.personD.samplingUsers = [];
            var samplePersonNameStr = "";
            for (var i = 0; i < this.formControl.samplePersonSelected.length; i++) {
                samplePersonNameStr = samplePersonNameStr + this.formControl.samplePersonSelected[i].real_NAME;
                if (i < this.formControl.samplePersonSelected.length - 1) {
                    samplePersonNameStr += ",";
                }
                //往数组插入人员对象
                var obj = {};
                obj.id = i;
                obj.id = this.formControl.samplePersonSelected[i].user_ID,
                    // obj.username = this.formControl.samplePersonSelected[i].real_NAME,
                    // obj.realName = this.formControl.samplePersonSelected[i].real_NAME,
                    // obj.idCard = "",
                    obj.id = this.formControl.samplePersonSelected[i].user_ID,
                    obj.name = this.formControl.samplePersonSelected[i].real_NAME,
                    this.formData.personD.samplingUsers.push(obj);
            }
            }else {
                this.formData.personD.samplingUsers = [];
                var samplePersonNameStr = "";
                var obj = {};
                    // obj.id = i;
                    // obj.id = "",
                    // obj.username = "",
                    // obj.realName = "",
                    // obj.idCard = "",
                    obj.id = "";
                    obj.name = "";
                    this.formData.personD.samplingUsers.push(obj);
            }
            //////////////////////////////////////////////////
            this.result.samplingUsers = this.formData.personD.samplingUsers;
            this.result.samplingDateLong = this.formData.personD.samplingDateLong;
            this.showDialog.persons = false;
        },


    }
}