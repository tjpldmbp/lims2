function evenRound(num, decimalPlaces) {

    var d = decimalPlaces || 0;
    var m = Math.pow(10, d);
    var n = +(d ? num * m : num).toFixed(8); // Avoid rounding errors
    var i = Math.floor(n), f = n - i;
    var e = 1e-8; // Allow for rounding errors in f
    var r = (f > 0.5 - e && f < 0.5 + e) ?
        ((i % 2 == 0) ? i : i + 1) : Math.round(n);
    return d ? r / m : r;
}
function togetRealvalue(mVaue, bVaue) {
    var num = evenRound((mVaue - bVaue), 0);
    var realvalue = 0;
    if (num < 3) {
        return evenRound((mVaue - 0), 0);
    }
    else if (num === 3) {
        realvalue = mVaue - 3
        return evenRound(realvalue, 0);
    }
    else if (4 <= num && num <= 5) {
        realvalue = mVaue - 2
        return evenRound(realvalue, 0);
    }

    else if (6 <= num && num <= 10) {
        realvalue = mVaue - 1
        return evenRound(realvalue, 0);
    }

    else if (num > 10) {
        return evenRound((mVaue - 0), 0);
    }
}

///四舍六入
function EffectiveNum(orignNum, n) {
    if (orignNum.toString() == "NaN" || orignNum.toString() == "Infinity" || orignNum.toString() == "0") {
        return 0;
    }
    var returnNum;  //返回值
    var loc = parseInt(n) + 1;//位置，多次用到
    //用小数点拆分数字;修约分小数点前部分大于0和小数点前数字小于0两种情况
    var str;
    str = orignNum.toString().split(".");
    if (str.length < 1 || str.length > 2) //数字格式不正确 
    {
        return 0;
    }
    else if (str.length == 1) {
        str[1] = "";
    }
    //合并数字
    var uniteNum;
    if (parseInt(str[0]) == 0) {
        uniteNum = str[1];
    }
    else {
        uniteNum = str[0].concat(str[1]);
    }
    ////////////////////////////////////////////////////////////////////////////////////////////
    //小数点前部分大于0
    ////////////////////////////////////////////////////////////////////////////////////////////
    if (parseInt(str[0]) != 0) {
        var lenofnum = uniteNum.length;
        if (lenofnum <= n) {
            var shorter = n - lenofnum;
            var append = '';
            for (i = 0; i < shorter; i++) {
                append += '0';
            }
            returnNum = str[0] + '.' + str[1] + append;
        }
        //取舍的数字和舍弃的数字
        var mender = uniteNum.charAt(n);
        var leaver = uniteNum.slice(loc);
        //拟舍弃数字的最左一位数字大于5或者小于5
        if (parseInt(mender) > 5 || parseInt(mender) < 5) {
            returnNum = (parseFloat(orignNum)).toPrecision(n);
        }
        //拟舍弃数字的最左一位数字为5
        else if (parseInt(leaver) > 0) {
            returnNum = (parseFloat(orignNum)).toPrecision(n);
        }
        //拟舍弃数字的最左一位数字为5,5右面无数字
        else {
            var preNum = parseInt(uniteNum.charAt(n - 1));
            //末位数字为奇数
            if (preNum % 2 == 1) {
                returnNum = (parseFloat(orignNum)).toPrecision(n);
            }
            //末位数字为偶数,先修改原始数据，把末位数后的5去掉 
            else if (preNum % 2 == 0) {
                var len = str[0].length;
                //有效位数n小于等于原始数据中整数部分的长度，修正原始数据eg:1245354,有效数字为3位，凑个5000，1245354-5000=1240000来参与修约
                if (n < len) {
                    var subtract = "5";
                    for (i = 1; i < len - n; i++) {
                        subtract += "0";
                    }
                    orignNum = orignNum - parseInt(subtract);
                    returnNum = (parseFloat(orignNum)).toPrecision(n);
                }
                //有效位数n大于原始数据中整数部分的长度，直接取前n+1位数字,包括小数点
                else {
                    orignNum = parseFloat(orignNum.toString().slice(0, loc));
                    returnNum = (parseFloat(orignNum)).toPrecision(n);
                }
            }
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////
    //小数点前部分=0
    ////////////////////////////////////////////////////////////////////////////////////////////
    else {
        var lenstr1 = str[1].length;
        var valdata = 0;
        var last0 = 0;
        for (i = 0; i < lenstr1; i++) {
            var strtemp = str[1].charAt(i);
            if (strtemp != '0') {
                var valdata = str[1].substr(i);
                var last0 = i + 1;
                break;
            }
        }
        var lenofnum = valdata.length;
        if (valdata.length <= n) {
            var shorter = n - lenofnum;
            var append = '';
            for (i = 0; i < shorter; i++) {
                append += '0';
            }
            returnNum = str[0] + '.' + str[1] + append;
        }
        var mender = valdata.charAt(n);
        var leaver = valdata.slice(loc);
        //拟舍弃数字的最左一位数字大于5或者小于5
        if (parseInt(mender) > 5 || parseInt(mender) < 5) {
            returnNum = (parseFloat(orignNum)).toPrecision(n);
        }
        //拟舍弃数字的最左一位数字为5
        else if (parseInt(leaver) > 0) {
            returnNum = (parseFloat(orignNum)).toPrecision(n);
        }
        //5右面无数字或者皆为0
        else {
            var preNum = parseInt(valdata.charAt(n - 1));
            //5右面无数字或者皆为0或末位数字为奇数
            if (preNum % 2 == 1) {
                returnNum = (parseFloat(orignNum)).toPrecision(n);
            }
            //末位数字为偶数,先修改原始数据，*****把末位数后的5去掉***** 
            else if (preNum % 2 == 0) {
                var subtract = "0.";
                for (i = 0; i < last0; i++) {
                    subtract += "0";
                }
                var len = valdata.length;
                if (n < len) {
                    for (i = 0; i < n; i++) {
                        subtract += "0";
                    }
                    subtract += "5";
                    orignNum = orignNum - parseFloat(subtract);
                    returnNum = (parseFloat(orignNum)).toPrecision(n);
                }
            }
        }
    }
    return returnNum;
}

//日期
(function () {
    Date.prototype.format = function (format) {
        var o = {
            "M+": this.getMonth() + 1, //month
            "d+": this.getDate(),    //day
            "h+": this.getHours(),   //hour
            "m+": this.getMinutes(), //minute
            "s+": this.getSeconds(), //second
            "q+": Math.floor((this.getMonth() + 3) / 3),  //quarter
            "S": this.getMilliseconds() //millisecond
        }
        if (/(y+)/.test(format)) format = format.replace(RegExp.$1,
            (this.getFullYear() + "").substr(4 - RegExp.$1.length));
        for (var k in o) if (new RegExp("(" + k + ")").test(format))
            format = format.replace(RegExp.$1,
                RegExp.$1.length == 1 ? o[k] :
                    ("00" + o[k]).substr(("" + o[k]).length));
        return format;
    }
})();


gpsData = [{
    defaultIndex: 0,
    values: ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'],
    className: 'c1'
}, {
    defaultIndex: 0,
    values: ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'],
    className: 'c2'
}, {
    defaultIndex: 0,
    values: ['0°', '1°', '2°', '3°', '4°', '5°', '6°', '7°', '8°', '9°'],
    className: 'c3'
}, {
    defaultIndex: 0,
    values: ['0', '1', '2', '3', '4', '5'],
    className: 'c4'
}, {
    defaultIndex: 0,
    values: ['0′', '1′', '2′', '3′', '4′', '5′', '6′', '7′', '8′', '9′'],
    className: 'c5'
}, {
    defaultIndex: 0,
    values: ['0', '1', '2', '3', '4', '5'],
    className: 'c6'
}, {
    defaultIndex: 0,
    values: ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'],
    className: 'c7'
}, {
    defaultIndex: 0,
    values: ['.0″', '.1″', '.2″', '.3″', '.4″', '.5″', '.6″', '.7″', '.8″', '.9″'],
    className: 'c8'
}];