//仪器弹出框模块

instrumen_component = {

    data: {
        showDialog: {

            picker: {

                //被校准设备 
                showbeijiaozhun: false,
                   //新增采样仪器绑定{}
                   objsamplingInstrument: false,

            },
            //仪器总模块
            instrumentModel: false, //仪器模块总下拉框
            instrumentpicker: {
                //测量仪器录入时间
                celiang_startDateTime: false,
                celiang_endDateTime: false,
                //声级校准时间
                shengji_startDateTime: false,
                shengji_endDateTime: false,
                //辅助仪器时间
                fuzhu_startDateTime: false,
                fuzhu_endDateTime: false,
                measuring: false,//测量仪器
                soundlevel: false,//声级仪器
                auxiliary: false,//辅助仪器
            },
            otherspicker: {
                mytest: false,
            },
        },
        formControl: {
            searchBase: "",//仪器搜索初始化搜索字段
            //测量仪器录入时间
            celiang_startDateTime: new Date(),
            celiang_endDateTime: new Date(),
            //声级校准仪器录入时间
            shengji_startDateTime: new Date(),
            shengji_endDateTime: new Date(),
            //辅助仪器时间
            fuzhu_startDateTime: new Date(),
            fuzhu_endDateTime: new Date(),
            //测量仪器数据
            Index_CL: "测量",
            Index_JZ: "校准",
            Index_FZ: "辅助",

            JianceDate_yq: new Date(),//监测时间初始化日期
            startDateTime: new Date(),
            endDateTime: new Date(),

            celiang_yqALL: [],
            celiang_yq: [],
            //测量仪器选中
            celiang_yqSelected: [],
            shengji_yqALL: [],
            //校准仪器
            shengji_yq: [],
            //校准仪器选中
            shengji_yqSelected: [],
            //被校准仪器
            beijiaozhunSelected: [],
            //新增校准仪器临时选择项
            linshiJiaozhunModel: {},

            fuzhu_yqALL: [],
            //辅助仪器
            fuzhu_yq: [],
            //辅助仪器选中
            fuzhu_yqSelected: [],

                //新增采样仪器绑定数组
                bangdingarry_yq: [],
                bangdingarry_yqSelected: [],



        },
        formData: {
            row: {
                //注意必须加入
                samplingInstrument: {},
            },//多行模块下拉内容
            
            instrumentModelD: {
                //测量仪器
                MEASURINGS: [
                    {
                        "startDateLong": 0,
                        "endDateLong": 0,
                        "id": "",
                        "model": "",
                        "name": "",
                        "manageNumber": "",
                        "purpose": "",
                        "state": "",
                        "checked": ""
                    }
                ],

                //声级校准仪器
                SOUNDLEVELS: [{
                    "startDateLong": 0,
                    "endDateLong": 0,
                    "id": "",
                    "model": "",
                    "name": "",
                    "manageNumber": "",
                    "purpose": "",
                    "state": "",
                    "checked": "",
                    // "calibrationeds": []
                }],

                //辅助仪器
                AUXILIARYS: [{
                    "startDateLong": 0,
                    "endDateLong": 0,
                    "id": "",
                    "model": "",
                    "name": "",
                    "manageNumber": "",
                    "purpose": "",
                    "state": "",
                    "checked": ""
                }]


            },
        }
    },


    methods: {


        celiang_yqclickselect(item, index) {
            var ischecked = false;
            for (var i = 0; i < this.formControl.celiang_yqSelected.length; i++) {
                //判断选中数组是否存在点击对象
                if (this.formControl.celiang_yqSelected[i].f_ID == item.f_ID) {
                    ischecked = true;
                }
            }
            if (ischecked) {
                this.formControl.celiang_yqSelected.remove(item);
            } else {
                //加上是单选 去掉是多选
                // this.formControl.standardBasisSelected = [];
                //插入
                this.formControl.celiang_yqSelected.push(item);


            }
        },


        fuzhu_yqclickselect(item, index) {
            console.log("--辅助1-->", item)
            console.log("--辅助Selected-->", this.formControl.fuzhu_yqSelected)
            var ischecked = false;
            for (var i = 0; i < this.formControl.fuzhu_yqSelected.length; i++) {
                //判断选中数组是否存在点击对象
                if (this.formControl.fuzhu_yqSelected[i].f_ID == item.f_ID) {
                    ischecked = true;
                }
            }
            if (ischecked) {
                this.formControl.fuzhu_yqSelected.remove(item);
            } else {
                //加上是单选 去掉是多选
                // this.formControl.fuzhu_yqSelected = [];
                //插入
                this.formControl.fuzhu_yqSelected.push(item);

            }
        },
        //三级界面点击选择对象
        beijiaozhunSlectChecked(item, index) {
            //选择多个
            var ischecked = false;
            for (var i = 0; i < this.formControl.beijiaozhunSelected.length; i++) {
                //判断选中数组是否存在点击对象
                if (this.formControl.beijiaozhunSelected[i].f_ID == item.f_ID) {
                    ischecked = true;
                }
            }
            if (ischecked) {

                this.formControl.beijiaozhunSelected.remove(item);
            } else {
                //加上是单选 去掉是多选
                // this.formControl.beijiaozhunSelected = [];
                //插入
                this.formControl.beijiaozhunSelected.push(item);

            }
        },


        //校准设备列表点击
        singleChecked(item, index) {
            var istrue = false;
            console.log("点击校准时候已经被选中的数组-->", this.formControl.shengji_yqSelected)
            console.log("校准点击-->", item)

            this.formControl.linshiJiaozhunModel = {};
            this.formControl.beijiaozhunSelected = [];

            if (this.formControl.shengji_yqSelected.length > 0) {

                for (var i = 0; i < this.formControl.shengji_yqSelected.length; i++) {
                    //判断选中数组是否存在点击对象
                    if (this.formControl.shengji_yqSelected[i].f_ID == item.f_ID) {

                        //转换calibrationeds 为f_ID类型
                        for (var j = 0; j < this.formControl.shengji_yqSelected[i].calibrationeds.length; j++) {
                            //初始化辅助仪器选择 
                            for (var h = 0; h < this.formControl.celiang_yqSelected.length; h++) {
                                if (this.formControl.shengji_yqSelected[i].calibrationeds[j].id == this.formControl.celiang_yqSelected[h].f_ID) {
                                    this.formControl.beijiaozhunSelected.push(this.formControl.celiang_yqSelected[h]);
                                }
                            }

                        }
                        this.formControl.linshiJiaozhunModel = this.formControl.shengji_yqSelected[i];//临时点击对象
                        istrue = true;

                    }

                }






            }

            if (!istrue) {
                Object.assign(item, {
                    //给采样池子赋值初始化值
                    "calibrationeds": [],
                });
                this.formControl.linshiJiaozhunModel = item;

            }


            //打开三级
            this.showDialog.picker.showbeijiaozhun = true

        },

        /////////////////////////////////////////仪器选择区域//////////////////////////////////////////////////////
        //仪器选择
        makeInstruMentModel() {
            //测量
            if (this.result.samplingInstrument.length > 0) {
                this.formControl.celiang_yqSelected = [];
                this.formData.instrumentModelD.MEASURINGS = []
                for (var i = 0; i < this.result.samplingInstrument.length; i++) {
                    if (this.result.samplingInstrument[i].purpose != "") {
                        this.formData.instrumentModelD.MEASURINGS.push(this.result.samplingInstrument[i]);
                        //每种仪器时间选择
                        this.result.samplingInstrument[i].startDateLong = this.result.samplingInstrument[i].startDateLong == null || this.result.samplingInstrument[i].startDateLong == 0 || this.result.samplingInstrument[i].startDateLong == undefined ? new Date().getTime() : this.result.samplingInstrument[i].startDateLong;
                        this.formData.instrumentModelD.celiang_startDateLong = this.result.samplingInstrument[i].startDateLong;
                        this.formControl.celiang_startDateTime = new Date(this.result.samplingInstrument[i].startDateLong);

                        this.result.samplingInstrument[i].endDateLong = this.result.samplingInstrument[i].endDateLong == null || this.result.samplingInstrument[i].endDateLong == 0 || this.result.samplingInstrument[i].endDateLong == undefined ? new Date().getTime() : this.result.samplingInstrument[i].endDateLong;
                        this.formData.instrumentModelD.celiang_endDateLong = this.result.samplingInstrument[i].endDateLong;
                        this.formControl.celiang_endDateTime = new Date(this.result.samplingInstrument[i].endDateLong);
                        //初始化测量仪器选择
                        for (var j = 0; j < this.formControl.celiang_yq.length; j++) {
                            if (this.result.samplingInstrument[i].id == this.formControl.celiang_yq[j].f_ID) {
                                this.formControl.celiang_yqSelected.push(this.formControl.celiang_yq[j]);

                            }
                        }
                    }
                }

            } else {
                //没有仪器时候默认选择时间当前时间  去掉默认是空
                // this.formData.instrumentModelD.celiang_startDateLong = new Date();
                // this.formData.instrumentModelD.celiang_endDateLong = new Date();
            }



            //校准声级

            if (this.result.calibrationedsInstrument.length > 0) {
                this.formControl.shengji_yqSelected = [];
                this.formData.instrumentModelD.SOUNDLEVELS = []
                for (var i = 0; i < this.result.calibrationedsInstrument.length; i++) {
                    if (this.result.calibrationedsInstrument[i].purpose != "") {
                        this.formData.instrumentModelD.SOUNDLEVELS.push(this.result.calibrationedsInstrument[i]);
                        //每种仪器时间选择
                        this.result.calibrationedsInstrument[i].startDateLong = this.result.calibrationedsInstrument[i].startDateLong == null || this.result.calibrationedsInstrument[i].startDateLong == 0 || this.result.calibrationedsInstrument[i].startDateLong == undefined ? new Date().getTime() : this.result.calibrationedsInstrument[i].startDateLong;
                        this.formData.instrumentModelD.shengji_startDateLong = this.result.calibrationedsInstrument[i].startDateLong;
                        this.formControl.shengji_startDateTime = new Date(this.result.calibrationedsInstrument[i].startDateLong);

                        this.result.calibrationedsInstrument[i].endDateLong = this.result.calibrationedsInstrument[i].endDateLong == null || this.result.calibrationedsInstrument[i].endDateLong == 0 || this.result.calibrationedsInstrument[i].endDateLong == undefined ? new Date().getTime() : this.result.calibrationedsInstrument[i].endDateLong;
                        this.formData.instrumentModelD.shengji_endDateLong = this.result.calibrationedsInstrument[i].endDateLong;
                        this.formControl.shengji_endDateTime = new Date(this.result.calibrationedsInstrument[i].endDateLong);

                        //初始化声级校准仪器选择
                        for (var j = 0; j < this.formControl.shengji_yq.length; j++) {
                            if (this.result.calibrationedsInstrument[i].id == this.formControl.shengji_yq[j].f_ID) {
                                this.formControl.shengji_yqSelected.push(this.formControl.shengji_yq[j]);
                                // this.formControl.shengji_yqSelected.push(this.result.calibrationedsInstrument[i]);
                            }
                        }

                    }
                }
            } else {
                // this.formData.instrumentModelD.shengji_startDateLong = new Date();
                // this.formData.instrumentModelD.shengji_endDateLong = new Date();
            }



            //辅助
            if (this.result.assistInstrument.length > 0) {
                this.formControl.fuzhu_yqSelected = [];
                this.formData.instrumentModelD.AUXILIARYS = []
                for (var i = 0; i < this.result.assistInstrument.length; i++) {
                    if (this.result.assistInstrument[i].purpose != "") {
                        this.formData.instrumentModelD.AUXILIARYS.push(this.result.assistInstrument[i]);
                        //每种仪器时间选择
                        this.result.assistInstrument[i].startDateLong = this.result.assistInstrument[i].startDateLong == null || this.result.assistInstrument[i].startDateLong == 0 || this.result.assistInstrument[i].startDateLong == undefined ? new Date().getTime() : this.result.assistInstrument[i].startDateLong;
                        this.formData.instrumentModelD.fuzhu_startDateLong = this.result.assistInstrument[i].startDateLong;
                        this.formControl.fuzhu_startDateTime = new Date(this.result.assistInstrument[i].startDateLong);

                        this.result.assistInstrument[i].endDateLong = this.result.assistInstrument[i].endDateLong == null || this.result.assistInstrument[i].endDateLong == 0 || this.result.assistInstrument[i].endDateLong == undefined ? new Date().getTime() : this.result.assistInstrument[i].endDateLong;
                        this.formData.instrumentModelD.fuzhu_endDateLong = this.result.assistInstrument[i].endDateLong;
                        this.formControl.fuzhu_endDateTime = new Date(this.result.assistInstrument[i].endDateLong);
                        //初始化辅助仪器选择
                        for (var j = 0; j < this.formControl.fuzhu_yq.length; j++) {
                            if (this.result.assistInstrument[i].id == this.formControl.fuzhu_yq[j].f_ID) {
                                this.formControl.fuzhu_yqSelected.push(this.formControl.fuzhu_yq[j]);
                            }
                        }
                    }
                }
            } else {
                // this.formData.instrumentModelD.fuzhu_startDateLong = new Date();
                // this.formData.instrumentModelD.fuzhu_endDateLong = new Date();
            }
            this.showDialog.instrumentModel = true;
        },


        //测量搜索过滤
        onSearchCeliang_yq(value) {
            if (value == "" || value == null || value == undefined) {
                this.formControl.celiang_yq = this.formControl.celiang_yqALL;
            } else {

                this.formControl.celiang_yq = this.formControl.celiang_yqALL;

                //过滤，挑选出满足条件的元素项
                var nameresult = this.formControl.celiang_yq.filter(function (item, index, array) {   //返回数组，filter函数获取满足条件的项
                    return (item.f_NAME.indexOf(value) != -1);
                });

                this.formControl.celiang_yq = nameresult;


            }

        },
        //声级校准搜索过滤
        onSearchShengji_yq(value) {

            if (value == "" || value == null || value == undefined) {
                this.formControl.shengji_yq = this.formControl.shengji_yqALL;
            } else {
                this.formControl.shengji_yq = this.formControl.shengji_yqALL;
                //过滤，挑选出满足条件的元素项
                var nameresult = this.formControl.shengji_yq.filter(function (item, index, array) {   //返回数组，filter函数获取满足条件的项
                    return (item.f_NAME.indexOf(value) != -1);
                });
                this.formControl.shengji_yq = nameresult;
            }

        },
        //辅助仪器搜索过滤
        onSearchFuzhu_yq(value) {
            if (value == "" || value == null || value == undefined) {
                this.formControl.fuzhu_yq = this.formControl.fuzhu_yqALL;
            } else {
                this.formControl.fuzhu_yq = this.formControl.fuzhu_yqALL;
                //过滤，挑选出满足条件的元素项
                var nameresult = this.formControl.fuzhu_yq.filter(function (item, index, array) {   //返回数组，filter函数获取满足条件的项
                    return (item.f_NAME.indexOf(value) != -1);
                });
                this.formControl.fuzhu_yq = nameresult;
            }

        },

        //测量仪器点击事件
        confirmMeasuring() {
            if (this.formControl.celiang_yqSelected.length > 0) {
                this.formData.instrumentModelD.MEASURINGS = [];
                for (var i = 0; i < this.formControl.celiang_yqSelected.length; i++) {
                    var obj = {};
                    obj.name = this.formControl.celiang_yqSelected[i].f_NAME;
                    obj.manageNumber = this.formControl.celiang_yqSelected[i].f_MANAGE_NO;
                    obj.id = this.formControl.celiang_yqSelected[i].f_ID;
                    obj.purpose = this.formControl.celiang_yqSelected[i].purpose_NAME;
                    obj.state = this.formControl.celiang_yqSelected[i].state;
                    obj.model = this.formControl.celiang_yqSelected[i].instrument_MODEL;
                    this.formData.instrumentModelD.MEASURINGS.push(obj);




                }
            } else {
                //重置初始化值
                this.formData.instrumentModelD.MEASURINGS = [];
                if (this.formControl.celiang_yqSelected.length == 0) {
                    var obj = {};
                    obj.startDateLong = 0;
                    obj.endDateLong = 0;
                    obj.id = "";
                    obj.model = "";
                    obj.name = "";
                    obj.manageNumber = "";
                    obj.purpose = "";
                    obj.state = "";
                    obj.checked = "";
                    this.formData.instrumentModelD.MEASURINGS.push(obj);
                }
            }

            console.log("---confirmMeasuring-->", this.formData.instrumentModelD.MEASURINGS)



            this.showDialog.instrumentpicker.measuring = false;
        },




        //声级仪器点击事件
        confirmSoundlevel() {
            console.log("点击最外面校准后comit", this.formControl.shengji_yqSelected)



            if (this.formControl.shengji_yqSelected.length > 0) {
                this.formData.instrumentModelD.SOUNDLEVELS = [];

                for (var i = 0; i < this.formControl.shengji_yqSelected.length; i++) {
                    var obj = {};
                    obj.name = this.formControl.shengji_yqSelected[i].f_NAME;
                    obj.manageNumber = this.formControl.shengji_yqSelected[i].f_MANAGE_NO;
                    obj.id = this.formControl.shengji_yqSelected[i].f_ID;
                    obj.purpose = this.formControl.shengji_yqSelected[i].purpose_NAME;
                    obj.state = this.formControl.shengji_yqSelected[i].state;
                    obj.model = this.formControl.shengji_yqSelected[i].instrument_MODEL;
                    obj.calibrationeds = this.formControl.shengji_yqSelected[i].calibrationeds;
                    this.formData.instrumentModelD.SOUNDLEVELS.push(obj);
                }
            } else {
                this.formData.instrumentModelD.SOUNDLEVELS = [];
                if (this.formControl.shengji_yqSelected.length == 0) {
                    var obj = {};
                    obj.startDateLong = 0;
                    obj.endDateLong = 0;
                    obj.id = "";
                    obj.model = "";
                    obj.name = "";
                    obj.manageNumber = "";
                    obj.purpose = "";
                    obj.state = "";
                    obj.checked = "";
                    this.formData.instrumentModelD.SOUNDLEVELS.push(obj);
                }
            }
            console.log("---jiaozhun-->", this.formData.instrumentModelD.SOUNDLEVELS)
            this.showDialog.instrumentpicker.soundlevel = false;

        },

        //<!-- 绑定被校准设备 -->
        confirmshowbeijiaozhun() {
            console.log("------------conmim当前临时校准对象--->", this.formControl.linshiJiaozhunModel);
            var calibrationeds = [];
            console.log("被校准--->", this.formControl.beijiaozhunSelected)
            if (this.formControl.beijiaozhunSelected.length > 0) {
                for (var j = 0; j < this.formControl.beijiaozhunSelected.length; j++) {
                    var obj = {};
                    obj.name = this.formControl.beijiaozhunSelected[j].f_NAME;
                    obj.manageNumber = this.formControl.beijiaozhunSelected[j].f_MANAGE_NO;
                    obj.id = this.formControl.beijiaozhunSelected[j].f_ID;
                    obj.state = this.formControl.beijiaozhunSelected[j].state;
                    obj.purpose = this.formControl.beijiaozhunSelected[j].purpose_NAME;
                    obj.startDateLong = Date.now();
                    obj.endDateLong = Date.now();
                    obj.checked = "";
                    obj.model = this.formControl.beijiaozhunSelected[j].instrument_MODEL;
                    calibrationeds.push(obj);
                }
                // //插入
                this.formControl.linshiJiaozhunModel.calibrationeds = calibrationeds;
                var mischecked = false;
                for (var i = 0; i < this.formControl.shengji_yqSelected.length; i++) {
                    //判断选中数组是否存在点击对象
                    if (this.formControl.shengji_yqSelected[i].f_ID == this.formControl.linshiJiaozhunModel.f_ID) {
                        mischecked = true;
                    }
                }
                if (mischecked) {
                } else {
                    //插入
                    this.formControl.shengji_yqSelected.push(this.formControl.linshiJiaozhunModel);
                }
            }
            //当没有被选中时候清空 
            else {
                this.formControl.shengji_yqSelected.remove(this.formControl.linshiJiaozhunModel);
            }
            this.showDialog.picker.showbeijiaozhun = false
        },




        //辅助仪器点击事件
        confirmAuxiliary() {
            console.log("--辅助Selected222222222-->", this.formControl.fuzhu_yqSelected)
            if (this.formControl.fuzhu_yqSelected.length > 0) {
                this.formData.instrumentModelD.AUXILIARYS = [];

                for (var i = 0; i < this.formControl.fuzhu_yqSelected.length; i++) {
                    var obj = {};
                    obj.name = this.formControl.fuzhu_yqSelected[i].f_NAME;
                    obj.manageNumber = this.formControl.fuzhu_yqSelected[i].f_MANAGE_NO;
                    obj.id = this.formControl.fuzhu_yqSelected[i].f_ID;
                    obj.purpose = this.formControl.fuzhu_yqSelected[i].purpose_NAME;
                    obj.state = this.formControl.fuzhu_yqSelected[i].state;
                    obj.model = this.formControl.fuzhu_yqSelected[i].instrument_MODEL;
                    this.formData.instrumentModelD.AUXILIARYS.push(obj);

                }
            }
            else {
                this.formData.instrumentModelD.AUXILIARYS = [];
                if (this.formControl.fuzhu_yqSelected.length == 0) {
                    var obj = {};
                    obj.startDateLong = 0;
                    obj.endDateLong = 0;
                    obj.id = "";
                    obj.model = "";
                    obj.name = "";
                    obj.manageNumber = "";
                    obj.purpose = "";
                    obj.state = "";
                    obj.checked = "";
                    this.formData.instrumentModelD.AUXILIARYS.push(obj);
                }
            }
            console.log("--辅助Selected333-->", this.formData.instrumentModelD.AUXILIARYS)
            this.showDialog.instrumentpicker.auxiliary = false;
        },

        //测量仪器开始时间
        confirmCL_StartDateTime(value) {
            var result = value.getTime();
            this.formData.instrumentModelD.celiang_startDateLong = result;
            this.showDialog.instrumentpicker.celiang_startDateTime = false;
        },
        //测量仪器结束时间
        confirmCL_EndDateTime(value) {
            var result = value.getTime();
            this.formData.instrumentModelD.celiang_endDateLong = result;
            this.showDialog.instrumentpicker.celiang_endDateTime = false
        },

        //声级校准仪器开始时间
        confirmJZ_StartDateTime(value) {
            var result = value.getTime();
            this.formData.instrumentModelD.shengji_startDateLong = result;
            this.showDialog.instrumentpicker.shengji_startDateTime = false;
        },
        //声级仪器结束时间
        confirmJZ_EndDateTime(value) {
            var result = value.getTime();
            this.formData.instrumentModelD.shengji_endDateLong = result;
            this.showDialog.instrumentpicker.shengji_endDateTime = false

        },

        //辅助仪器开始时间
        confirmFZ_StartDateTime(value) {
            var result = value.getTime();
            this.formData.instrumentModelD.fuzhu_startDateLong = result;
            this.showDialog.instrumentpicker.fuzhu_startDateTime = false;
        },
        //辅助仪器结束时间
        confirmFZ_EndDateTime(value) {
            var result = value.getTime();
            this.formData.instrumentModelD.fuzhu_endDateLong = result;
            this.showDialog.instrumentpicker.fuzhu_endDateTime = false

        },

        //所有仪器下拉点击确定事件
        confirminstrumentModel() {
            //测量采集仪器
            this.result.samplingInstrument = [];
            //仪器更替数据
            for (var i = 0; i < this.formData.instrumentModelD.MEASURINGS.length; i++) {
                if (this.formData.instrumentModelD.MEASURINGS[i].purpose != "") {
                    //赋值时间给result
                    this.formData.instrumentModelD.MEASURINGS[i].startDateLong = this.formData.instrumentModelD.celiang_startDateLong
                    this.formData.instrumentModelD.MEASURINGS[i].endDateLong = this.formData.instrumentModelD.celiang_endDateLong
                    this.result.samplingInstrument.push(this.formData.instrumentModelD.MEASURINGS[i])
                }

            }

            console.log(this.formData.instrumentModelD.SOUNDLEVELS)

            //校准仪器
            this.result.calibrationedsInstrument = [];
            //仪器更替数据
            for (var i = 0; i < this.formData.instrumentModelD.SOUNDLEVELS.length; i++) {
                if (this.formData.instrumentModelD.SOUNDLEVELS[i].purpose != "") {
                    //赋值时间给result
                    this.formData.instrumentModelD.SOUNDLEVELS[i].startDateLong = this.formData.instrumentModelD.shengji_startDateLong
                    this.formData.instrumentModelD.SOUNDLEVELS[i].endDateLong = this.formData.instrumentModelD.shengji_endDateLong

                    this.result.calibrationedsInstrument.push(this.formData.instrumentModelD.SOUNDLEVELS[i])

                }
            }

            //辅助仪器
            this.result.assistInstrument = [];
            //仪器更替数据
            for (var i = 0; i < this.formData.instrumentModelD.AUXILIARYS.length; i++) {
                if (this.formData.instrumentModelD.AUXILIARYS[i].purpose != "") {
                    //赋值时间给result
                    this.formData.instrumentModelD.AUXILIARYS[i].startDateLong = this.formData.instrumentModelD.fuzhu_startDateLong
                    this.formData.instrumentModelD.AUXILIARYS[i].endDateLong = this.formData.instrumentModelD.fuzhu_endDateLong
                    this.result.assistInstrument.push(this.formData.instrumentModelD.AUXILIARYS[i])
                }

            }
            console.log("打印辅助AUXILIARYS", this.formData.instrumentModelD.AUXILIARYS)
            console.log("打印1", this.result.samplingInstrument)
            console.log("打印2", this.result.calibrationedsInstrument)
            console.log("打印3", this.result.assistInstrument)
            this.showDialog.instrumentModel = false;

        },

        makeTest() {
            console.log("点击了makeTest")
            this.showDialog.otherspicker.mytest = true
        },
        confirmTest() {
            console.log("点击了提交")
        },

        makeJiaoZhun() {
            console.log("make校准", this.formControl.shengji_yqSelected);
            this.showDialog.instrumentpicker.soundlevel = true;
        }
        ,//绑定仪器到采样model
         //采样绑定model
         makeBangding() {
            this.formControl.bangdingarry_yq = this.formControl.celiang_yqSelected;
            this.showDialog.picker.objsamplingInstrument = true;
        },
        //绑定sapleList的samplingInstrument
        confirmBangDingModel() {
            console.log("点击了！！！", this.formControl.bangdingarry_yqSelected)
            if (this.formControl.bangdingarry_yqSelected.length > 0) {
                // this.formData.row.samplingInstrument = this.formControl.bangdingarry_yqSelected[0];
                var obj = {};
                obj.name = this.formControl.bangdingarry_yqSelected[0].f_NAME;
                obj.manageNumber = this.formControl.bangdingarry_yqSelected[0].f_MANAGE_NO;
                obj.id = this.formControl.bangdingarry_yqSelected[0].f_ID;
                obj.purpose = this.formControl.bangdingarry_yqSelected[0].purpose_NAME;
                obj.state = this.formControl.bangdingarry_yqSelected[0].state;
                obj.checked = "";
                obj.model = this.formControl.bangdingarry_yqSelected[0].instrument_MODEL;
                this.formData.row.samplingInstrument = obj;

            }
            console.log("样品绑定--->", this.formData.row.samplingInstrument)

            this.showDialog.picker.objsamplingInstrument = false;

        },
         //绑定sapleList的items的analyzeInstrument分析仪器 因子绑定
         confirmItemsBangDingModel() {
            console.log("点击了！！！", this.formControl.bangdingarry_yqSelected)
            if (this.formControl.bangdingarry_yqSelected.length > 0) {
                var obj = {};
                obj.name = this.formControl.bangdingarry_yqSelected[0].f_NAME;
                obj.manageNumber = this.formControl.bangdingarry_yqSelected[0].f_MANAGE_NO;
                obj.id = this.formControl.bangdingarry_yqSelected[0].f_ID;
                obj.purpose = this.formControl.bangdingarry_yqSelected[0].purpose_NAME;
                obj.state = this.formControl.bangdingarry_yqSelected[0].state;
                obj.checked = "";
                obj.model = this.formControl.bangdingarry_yqSelected[0].instrument_MODEL;
                this.formData.row.items[0].analyzeInstrument = obj;

            }
            console.log("因子绑定--->", this.formData.row.items[0].analyzeInstrument)

            this.showDialog.picker.objsamplingInstrument = false;

        },

        onSearchBangDingModel(value) {
            if (value == "" || value == null || value == undefined) {
                this.formControl.bangdingarry_yq = this.formControl.celiang_yqALL;
            } else {
                this.formControl.bangdingarry_yq = this.formControl.celiang_yqALL;
                //过滤，挑选出满足条件的元素项
                var nameresult = this.formControl.bangdingarry_yq.filter(function (item, index, array) {   //返回数组，filter函数获取满足条件的项
                    return (item.f_NAME.indexOf(value) != -1);
                });
                this.formControl.bangdingarry_yq = nameresult;
            }

        },
        bangdingarry_yqSelectedClick(item, index) {
            var ischecked = false;
            for (var i = 0; i < this.formControl.bangdingarry_yqSelected.length; i++) {
                //判断选中数组是否存在点击对象
                if (this.formControl.bangdingarry_yqSelected[i].f_ID == item.f_ID) {
                    ischecked = true;
                }
            }
            if (ischecked) {
                this.formControl.bangdingarry_yqSelected.remove(item);
            } else {
                //加上是单选 去掉是多选
                this.formControl.bangdingarry_yqSelected = [];
                //插入
                this.formControl.bangdingarry_yqSelected.push(item);

            }
        }
    }
}